﻿// Controls/KeyboardControl.xaml.cs (已修复线程冲突)
using System.Windows;
using System.Windows.Controls;
using System;
// 移除了不必要的 using 语句，只保留必需的

namespace MyPinyinKeyboard.Controls
{
    public partial class KeyboardControl : UserControl
    {
        public event EventHandler<KeyTappedEventArgs> KeyTapped;

        public KeyboardControl()
        {
            InitializeComponent();

            // 【✅ 修复点】移除了 this.Loaded += KeyboardControl_Loaded;
            // 移除了所有动态绑定事件的逻辑（KeyboardControl_Loaded, BindKeyEvents）
        }

        /// <summary>
        /// 统一的按钮点击事件处理程序。
        /// 这个方法将直接被 XAML 中的 Click="KeyButton_Click" 属性调用。
        /// </summary>
        public void KeyButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Content is string key)
            {
                TriggerKeyTapped(key);
            }
        }

        public void TriggerKeyTapped(string key)
        {
            var args = new KeyTappedEventArgs(key);
            KeyTapped?.Invoke(this, args);
        }
    }
}