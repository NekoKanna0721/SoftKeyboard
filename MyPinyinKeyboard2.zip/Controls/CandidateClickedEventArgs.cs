// Controls/CandidateClickedEventArgs.cs

using System;

namespace MyPinyinKeyboard.Controls
{
    // ע�⣺���� MainWindow.xaml.cs ��ʹ�õ������� CandidateClickedEventArgs
    public class CandidateClickedEventArgs : EventArgs
    {
        public int Index { get; }
        public string Candidate { get; }

        public CandidateClickedEventArgs(int index, string candidate)
        {
            Index = index;
            Candidate = candidate;
        }
    }
}