﻿using System;
using System.Linq;
using System.Threading;
using System.Collections.Generic;
using System.Security.Principal;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Threading;
using System.Windows.Media;
using WinForms = System.Windows.Forms;
using Key = System.Windows.Input.Key;

using MyPinyinKeyboard.Controls;
using MyPinyinKeyboard.Logic;

namespace MyPinyinKeyboard
{
    // 定义一个简单的主题结构
    public class AppTheme
    {
        public string AccentColor { get; set; }
        public string MainBackgroundColor { get; set; }
        public string SecondaryBackgroundColor { get; set; }
    }

    public partial class MainWindow : Window
    {
        // --------------------
        // Win32 API & 常量
        // --------------------
        [DllImport("user32.dll")]
        static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);
        [DllImport("user32.dll")]
        static extern int GetWindowLong(IntPtr hWnd, int nIndex);
        private const int GWL_EXSTYLE = -20;
        private const int WS_EX_NOACTIVATE = 0x08000000;
        private const int WS_EX_TOOLWINDOW = 0x00000080;

        // --------------------
        // 字段
        // --------------------
        private readonly PinyinEngine _engine;
        private bool _isSimulatingInput = false;

        private DispatcherTimer _backspaceTimer;
        private bool _isBackspaceHeld = false;
        private int _backspaceRepeatCount = 0;
        private bool _backspaceFirstExecutionDone = false;
        private const int BACKSPACE_DELAY_MS = 300;
        private const int BACKSPACE_REPEAT_INTERVAL_MS = 50;

        // 预设的渐变主题字典
        private Dictionary<string, AppTheme> _themes;

        // --------------------
        // 构造与生命周期
        // --------------------
        public MainWindow()
        {
            InitializeComponent();
            this.Topmost = true;
            _engine = new PinyinEngine();
            InitializeThemes(); // 初始化主题字典
            ApplyTheme("Monet"); // 默认应用莫奈主题

            this.Loaded += (s, e) =>
            {
                var helper = new WindowInteropHelper(this);
                IntPtr handle = helper.Handle;
                int extendedStyle = GetWindowLong(handle, GWL_EXSTYLE);
                SetWindowLong(handle, GWL_EXSTYLE, extendedStyle | WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW);

                KeyboardHook.KeyIntercepted += OnKeyIntercepted;
                KeyboardHook.Start();
                InitializeBackspaceTimer();
            };

            this.Closing += (s, e) =>
            {
                KeyboardHook.Stop();
                _backspaceTimer?.Stop();
            };

            if (!new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator))
            {
                System.Windows.MessageBox.Show("【重要】为确保输入法能向所有应用程序发送按键，请以管理员身份重新启动本程序。",
                                 "权限不足警告", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Warning);
            }
        }

        // --------------------
        // 主题管理
        // --------------------
        private void InitializeThemes()
        {
            _themes = new Dictionary<string, AppTheme>
            {
                { "Monet", new AppTheme { AccentColor = "#A7BED3", MainBackgroundColor = "#F2F2E4", SecondaryBackgroundColor = "#E4EDE4" } }, // 莫奈印象
                { "Forest", new AppTheme { AccentColor = "#66BB6A", MainBackgroundColor = "#F1F8E9", SecondaryBackgroundColor = "#E8F5E9" } },  // 森林之歌 (Accent: Green)
                { "DeepSea", new AppTheme { AccentColor = "#2962FF", MainBackgroundColor = "#E3F2FD", SecondaryBackgroundColor = "#BBDEFB" } }, // 深海秘境 (Accent: Deep Blue)
                { "Sakura", new AppTheme { AccentColor = "#F06292", MainBackgroundColor = "#FFEBEE", SecondaryBackgroundColor = "#FCE4EC" } },  // 樱花烂漫 (Accent: Pink)
                { "Coffee", new AppTheme { AccentColor = "#8D6E63", MainBackgroundColor = "#EFEBE9", SecondaryBackgroundColor = "#D7CCC8" } },  // 咖啡时光 (Accent: Brown)
                { "Desert", new AppTheme { AccentColor = "#FFB300", MainBackgroundColor = "#FFF8E1", SecondaryBackgroundColor = "#FFECB3" } },  // 沙漠落日 (Accent: Amber)
                { "Starlight", new AppTheme { AccentColor = "#673AB7", MainBackgroundColor = "#EDE7F6", SecondaryBackgroundColor = "#D1C4E9" } }, // 星空蓝紫 (Accent: Deep Purple)
                { "Frozen", new AppTheme { AccentColor = "#4FC3F7", MainBackgroundColor = "#E1F5FE", SecondaryBackgroundColor = "#B3E5FC" } },  // 冰雪奇缘 (Accent: Light Blue)
                { "Lemon", new AppTheme { AccentColor = "#FFD54F", MainBackgroundColor = "#FFFDE7", SecondaryBackgroundColor = "#FFF9C4" } },  // 阳光柠檬 (Accent: Yellow)
                { "Peach", new AppTheme { AccentColor = "#FFAB91", MainBackgroundColor = "#FBE9E7", SecondaryBackgroundColor = "#FFCCBC" } }   // 蜜桃甜心 (Accent: Light Coral)
            };
        }

        /// <summary>
        /// 根据主题名称应用配色方案。
        /// </summary>
        private void ApplyTheme(string themeName)
        {
            if (_themes.TryGetValue(themeName, out AppTheme theme))
            {
                SetThemeColors(theme.AccentColor, theme.MainBackgroundColor, theme.SecondaryBackgroundColor);
            }
            else
            {
                Debug.WriteLine($"[Theme] 主题 '{themeName}' 未找到，应用默认主题。");
                SetThemeColors("#00BCD4", "#E0F2F7", "#ECF0F1"); // Fallback to default
            }
        }

        /// <summary>
        /// 统一设置应用程序的强调色、主背景色和次要背景色。
        /// </summary>
        private void SetThemeColors(string accentColorHex, string mainBackgroundHex, string secondaryBackgroundHex)
        {
            var globalResources = Application.Current.Resources;

            // 辅助函数：将 Hex 字符串转换为 Color
            Color HexToColor(string hex)
            {
                return (Color)ColorConverter.ConvertFromString(hex);
            }

            // 1. 设置主色 (Accent)
            Color accentColor = HexToColor(accentColorHex);
            globalResources["AccentColor"] = accentColor;

            // 根据主色计算 Hover 和 Pressed 颜色
            Color accentHoverColor = Color.FromArgb(255,
                (byte)Math.Min(255, accentColor.R + 30),
                (byte)Math.Min(255, accentColor.G + 30),
                (byte)Math.Min(255, accentColor.B + 30));

            Color accentPressedColor = Color.FromArgb(255,
                (byte)Math.Max(0, accentColor.R - 20),
                (byte)Math.Max(0, accentColor.G - 20),
                (byte)Math.Max(0, accentColor.B - 20));

            globalResources["AccentBrush"] = new SolidColorBrush(accentColor);
            globalResources["AccentHoverBrush"] = new SolidColorBrush(accentHoverColor);
            globalResources["AccentPressedBrush"] = new SolidColorBrush(accentPressedColor);

            // 2. 设置主背景色 (Main Background)
            Color mainBackgroundColor = HexToColor(mainBackgroundHex);
            globalResources["MainBackgroundColor"] = mainBackgroundColor;
            globalResources["MainBackgroundBrush"] = new SolidColorBrush(mainBackgroundColor);

            // 3. 设置次要背景色 (Secondary Background)
            Color secondaryBackgroundColor = HexToColor(secondaryBackgroundHex);
            globalResources["SecondaryBackgroundColor"] = secondaryBackgroundColor;
            globalResources["SecondaryBackgroundBrush"] = new SolidColorBrush(secondaryBackgroundColor);

            Debug.WriteLine($"[Theme] New Theme Set. Accent: {accentColorHex}, MainBG: {mainBackgroundHex}, SecondaryBG: {secondaryBackgroundHex}");
        }

        /// <summary>
        /// 主题选择按钮的点击事件。从按钮的 Tag 中获取主题名称。
        /// </summary>
        private void ChangeTheme_Click(object sender, RoutedEventArgs e)
        {
            if (sender is System.Windows.Controls.Button button)
            {
                string themeName = button.Tag.ToString();
                ApplyTheme(themeName);
            }
        }


        // --------------------
        // Backspace 逻辑 (保持不变)
        // --------------------
        private void InitializeBackspaceTimer()
        {
            _backspaceTimer = new DispatcherTimer();
            _backspaceTimer.Interval = TimeSpan.FromMilliseconds(BACKSPACE_REPEAT_INTERVAL_MS);
            _backspaceTimer.Tick += BackspaceTimer_Tick;
        }

        private void BackspaceTimer_Tick(object sender, EventArgs e)
        {
            if (!_isBackspaceHeld)
            {
                _backspaceTimer.Stop();
                return;
            }

            _backspaceRepeatCount++;

            if (_backspaceRepeatCount * BACKSPACE_REPEAT_INTERVAL_MS >= BACKSPACE_DELAY_MS)
            {
                int speed = _backspaceRepeatCount < 10 ? 1 : (_backspaceRepeatCount < 30 ? 2 : 4);

                for (int i = 0; i < speed; i++)
                {
                    ProcessBackspaceKey();
                }
            }
        }

        private void ProcessBackspaceKey()
        {
            if (_engine.IsChineseMode && _engine.Buffer.Length > 0)
            {
                _engine.Backspace();
                UpdatePreviewAndCandidates();
                return;
            }
            SendInputKey("{BACKSPACE}");
            UpdatePreviewAndCandidates();
        }


        // --------------------
        // 钩子回调与输入拦截 (保持不变)
        // --------------------
        private bool OnKeyIntercepted(Key key, char charToProcess, int vkCode, bool isDown)
        {
            return (bool)this.Dispatcher.Invoke(() =>
            {
                return ProcessKeyboardInput(key, charToProcess, vkCode, isDown);
            });
        }

        private bool ProcessKeyboardInput(Key key, char charToProcess, int vkCode, bool isDown)
        {
            if (_isSimulatingInput || SettingsPanel.Visibility == Visibility.Visible)
            {
                return true;
            }

            if (!isDown)
            {
                if (key == Key.Back)
                {
                    _isBackspaceHeld = false;
                    _backspaceFirstExecutionDone = false;
                    _backspaceTimer.Stop();
                    return true;
                }
                return false;
            }

            if (key == Key.Back)
            {
                if (!_backspaceFirstExecutionDone)
                {
                    ProcessBackspaceKey();
                    _backspaceFirstExecutionDone = true;
                    _isBackspaceHeld = true;
                    _backspaceRepeatCount = 0;
                    _backspaceTimer.Start();
                }
                return true;
            }

            if (_isBackspaceHeld)
            {
                _isBackspaceHeld = false;
                _backspaceFirstExecutionDone = false;
                _backspaceTimer.Stop();
            }

            string virtualKey = "";
            bool isIntercepted = false;

            if (charToProcess != '\0' && char.IsLetter(charToProcess))
            {
                virtualKey = charToProcess.ToString();
                isIntercepted = true;
            }
            else if (key == Key.Space) { virtualKey = "SPACE"; isIntercepted = true; }
            else if (key == Key.Enter) { virtualKey = "ENTER"; isIntercepted = true; }
            else if (key == Key.Left) { virtualKey = "←"; isIntercepted = true; }
            else if (key == Key.Right) { virtualKey = "→"; isIntercepted = true; }
            else if ((key >= Key.D0 && key <= Key.D9) || key == Key.OemComma || key == Key.OemPeriod ||
                         key == Key.OemQuestion || key == Key.OemSemicolon || key == Key.OemQuotes ||
                         key == Key.OemOpenBrackets || key == Key.OemCloseBrackets || key == Key.OemPipe ||
                         key == Key.OemMinus || key == Key.OemPlus || key == Key.OemTilde)
            {
                virtualKey = GetSendKeysEquivalent(key);
                charToProcess = (char)vkCode;
                isIntercepted = true;
            }
            else if (key == Key.Tab) { virtualKey = "TAB"; isIntercepted = false; }
            else if (key == Key.Delete) { virtualKey = "DEL"; isIntercepted = false; }
            else if (key == Key.Capital) { virtualKey = "CAPS"; isIntercepted = false; }

            if (isIntercepted || !string.IsNullOrEmpty(virtualKey))
            {
                var args = new KeyTappedEventArgs(virtualKey)
                {
                    Char = charToProcess,
                    IsSpace = virtualKey == "SPACE",
                    IsBackspace = virtualKey == "BACKSPACE"
                };

                KeyboardControl_KeyTapped(KeyboardControl, args);
            }

            return isIntercepted;
        }

        // --------------------
        // SendKeys 等辅助 (保持不变)
        // --------------------
        private string GetSendKeysEquivalent(Key key)
        {
            if (key >= Key.D0 && key <= Key.D9) return key.ToString().Substring(1);
            if (key >= Key.A && key <= Key.Z) return key.ToString().ToLower();

            switch (key)
            {
                case Key.OemComma: return "{,}";
                case Key.OemPeriod: return "{.}";
                case Key.OemQuestion: return "{/}";
                case Key.OemSemicolon: return "{;}";
                case Key.OemQuotes: return "{'}";
                case Key.OemOpenBrackets: return "{[}";
                case Key.OemCloseBrackets: return "{]}";
                case Key.OemPipe: return @"{\}";
                case Key.OemMinus: return "{-}";
                case Key.OemPlus: return "{=}";
                case Key.OemTilde: return "{~}";
                default: return key.ToString();
            }
        }

        private void SendInputChar(char ch)
        {
            SendInputKey(ch.ToString());
        }

        private void SendInputKey(string sendKey)
        {
            if (string.IsNullOrEmpty(sendKey)) return;

            bool containsNonAscii = sendKey.Any(c => c > 127);

            _isSimulatingInput = true;
            try
            {
                if (containsNonAscii)
                {
                    SendTextViaClipboard(sendKey);
                    Debug.WriteLine($"[Input] Sent via clipboard paste: {sendKey}");
                }
                else
                {
                    try
                    {
                        WinForms.SendKeys.SendWait(sendKey);
                        Debug.WriteLine($"[Input] Sent: {sendKey}");
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"[Input] SendKeys failed: {ex.Message}. Fallback to clipboard.");
                        SendTextViaClipboard(sendKey);
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[Input] Exception in SendInputKey: {ex.Message}");
            }
            finally
            {
                _isSimulatingInput = false;
            }
        }

        private void SendTextViaClipboard(string text)
        {
            if (!this.Dispatcher.CheckAccess())
            {
                this.Dispatcher.Invoke(() => SendTextViaClipboard(text));
                return;
            }

            System.Windows.IDataObject originalData = null;
            bool originalDataAvailable = false;

            try
            {
                try
                {
                    originalData = System.Windows.Clipboard.GetDataObject();
                    originalDataAvailable = originalData != null;
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"[Clipboard] 读取剪贴板失败: {ex.Message}");
                    originalDataAvailable = false;
                }

                try
                {
                    System.Windows.Clipboard.SetText(text, System.Windows.TextDataFormat.UnicodeText);
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"[Clipboard] 设置剪贴板失败: {ex.Message}");
                    return;
                }

                Thread.Sleep(60);
                WinForms.SendKeys.SendWait("^v");
                Thread.Sleep(10);
            }
            finally
            {
                try
                {
                    if (originalDataAvailable && originalData != null)
                    {
                        System.Windows.Clipboard.SetDataObject(originalData, true);
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"[Clipboard] 恢复剪贴板失败: {ex.Message}");
                }
            }
        }


        // --------------------
        // 输入逻辑 (Space 和 CandidateSelected 强化) (保持不变)
        // --------------------
        private void KeyboardControl_KeyTapped(object sender, KeyTappedEventArgs e)
        {
            if (e.Key == "中/英")
            {
                if (_engine.Buffer.Length > 0)
                {
                    for (int i = 0; i < _engine.Buffer.Length; i++)
                    {
                        SendInputKey("{BACKSPACE}");
                    }
                }
                _engine.ToggleMode();
                _engine.Reset();
            }
            else if (e.Key == "BACKSPACE" || e.IsBackspace)
            {
                ProcessBackspaceKey();
            }
            else if (e.IsSpace)
            {
                if (_engine.IsChineseMode && _engine.Buffer.Length > 0)
                {
                    int pinyinLengthToClear = _engine.Buffer.Length;
                    string committedText = _engine.CommitBest();
                    string textToSend;

                    if (string.IsNullOrEmpty(committedText) || committedText == _engine.Buffer)
                    {
                        textToSend = _engine.Buffer + " ";
                    }
                    else
                    {
                        textToSend = committedText + " ";
                    }

                    for (int i = 0; i < pinyinLengthToClear; i++)
                    {
                        SendInputKey("{BACKSPACE}");
                    }

                    SendInputKey(textToSend);
                    _engine.Reset();
                }
                else
                {
                    SendInputKey(" ");
                }
            }
            else if (e.Key == "ENTER")
            {
                if (_engine.IsChineseMode && _engine.Buffer.Length > 0)
                {
                    int pinyinLengthToClear = _engine.Buffer.Length;
                    string leftover = _engine.CommitBest();

                    if (pinyinLengthToClear > 0)
                    {
                        for (int i = 0; i < pinyinLengthToClear; i++)
                        {
                            SendInputKey("{BACKSPACE}");
                        }
                    }

                    SendInputKey(leftover);
                    _engine.Reset();
                }
                SendInputKey("{ENTER}");
            }
            else if (e.Char != '\0')
            {
                if (_engine.IsChineseMode)
                {
                    if (char.IsPunctuation(e.Char) || char.IsSymbol(e.Char) || char.IsDigit(e.Char))
                    {
                        if (_engine.Buffer.Length > 0)
                        {
                            int pinyinLengthToClear = _engine.Buffer.Length;
                            string leftover = _engine.CommitBest();

                            if (pinyinLengthToClear > 0)
                            {
                                for (int i = 0; i < pinyinLengthToClear; i++)
                                {
                                    SendInputKey("{BACKSPACE}");
                                }
                            }
                            SendInputKey(leftover);
                            _engine.Reset();
                        }
                        SendInputChar(e.Char);
                    }
                    else
                    {
                        _engine.AddLetter(e.Char);
                        SendInputChar(e.Char);
                    }
                }
                else
                {
                    SendInputChar(e.Char);
                }
            }
            else if (e.Key == "TAB") { SendInputKey("{TAB}"); }
            else if (e.Key == "DEL") { SendInputKey("{DELETE}"); }
            else if (e.Key == "CAPS") { SendInputKey("{CAPSLOCK}"); }
            else if (e.Key == "→") { SendInputKey("{RIGHT}"); }
            else if (e.Key == "←") { SendInputKey("{LEFT}"); }

            UpdatePreviewAndCandidates();
        }

        private void CandidateBar_CandidateSelected(object sender, CandidateClickedEventArgs e)
        {
            int pinyinLengthToClear = _engine.Buffer.Length;
            var chosen = _engine.PickCandidate(e.Index);

            if (!string.IsNullOrEmpty(chosen))
            {
                if (pinyinLengthToClear > 0)
                {
                    for (int i = 0; i < pinyinLengthToClear; i++)
                    {
                        SendInputKey("{BACKSPACE}");
                    }
                }

                SendInputKey(chosen);

                _engine.Reset();
                UpdatePreviewAndCandidates();
            }
        }


        // --------------------
        // Window / UI (保持不变)
        // --------------------
        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed) { DragMove(); }
        }
        private void Close_Click(object sender, RoutedEventArgs e)
        {
            KeyboardHook.Stop(); _backspaceTimer?.Stop(); this.Close();
        }
        private void Minimize_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }
        private void Settings_Click(object sender, RoutedEventArgs e)
        {
            if (SettingsPanel.Visibility == Visibility.Visible)
            {
                SettingsPanel.Visibility = Visibility.Collapsed;
                KeyboardControl.Visibility = Visibility.Visible;
            }
            else
            {
                SettingsPanel.Visibility = Visibility.Visible;
                KeyboardControl.Visibility = Visibility.Collapsed;
            }
        }
        private void UpdatePreviewAndCandidates()
        {
            string modeIndicator = _engine.IsChineseMode ? "[中文]" : "[英文]";

            if (_engine.IsChineseMode && _engine.Buffer.Length > 0)
            {
                PreviewBox.Text = $"{modeIndicator} {_engine.Buffer}";
                CandidateBar.SetCandidates(_engine.GetCandidates());
            }
            else
            {
                PreviewBox.Text = modeIndicator;
                CandidateBar.SetCandidates(new List<string>());
            }
        }
    }
}