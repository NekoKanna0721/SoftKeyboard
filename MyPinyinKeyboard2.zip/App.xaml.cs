using System.Windows;

namespace MyPinyinKeyboard
{
    public partial class App : Application { }
}
