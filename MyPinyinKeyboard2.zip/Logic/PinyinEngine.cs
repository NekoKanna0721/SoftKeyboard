// Logic/PinyinEngine.cs - �����޸��汾

using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System;

namespace MyPinyinKeyboard.Logic
{
    public class PinyinEngine
    {
        private readonly Dictionary<string, List<string>> _pinyinDictionary = new Dictionary<string, List<string>>();
        private readonly StringBuilder _inputBuffer = new StringBuilder();

        public bool IsChineseMode { get; private set; } = true;

        public string Buffer => _inputBuffer.ToString();

        public PinyinEngine()
        {
            LoadDictionary();
        }

        private void LoadDictionary()
        {
            string dictPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "PinyinDict.txt");
            int entryCount = 0;

            if (File.Exists(dictPath))
            {
                var lines = File.ReadLines(dictPath);
                foreach (var line in lines)
                {
                    if (string.IsNullOrWhiteSpace(line)) continue;

                    var parts = line.Split(new[] { '\t' }, StringSplitOptions.RemoveEmptyEntries);

                    if (parts.Length >= 2)
                    {
                        string pinyin = parts[0].Trim().ToLower();
                        string word = parts[1].Trim();

                        if (!string.IsNullOrEmpty(pinyin) && !string.IsNullOrEmpty(word))
                        {
                            if (!_pinyinDictionary.ContainsKey(pinyin))
                            {
                                _pinyinDictionary[pinyin] = new List<string>();
                            }

                            _pinyinDictionary[pinyin].Add(word);
                            entryCount++;
                        }
                    }
                }
                System.Diagnostics.Debug.WriteLine($"[PinyinEngine] Dictionary loaded. Total Pinyin Keys: {_pinyinDictionary.Count}. Total words/phrases added: {entryCount}");
            }
            else
            {
                System.Diagnostics.Debug.WriteLine($"[PinyinEngine] ERROR: Dictionary file NOT FOUND at {dictPath}");
            }
        }

        public void ToggleMode()
        {
            IsChineseMode = !IsChineseMode;
            Reset();
            System.Diagnostics.Debug.WriteLine($"[PinyinEngine] Mode toggled to: {(IsChineseMode ? "Chinese" : "English")}");
        }

        public void AddLetter(char letter)
        {
            _inputBuffer.Append(char.ToLower(letter));
            System.Diagnostics.Debug.WriteLine($"[PinyinEngine] Buffer: {_inputBuffer}");
        }

        public void Backspace()
        {
            if (_inputBuffer.Length > 0)
            {
                _inputBuffer.Length--;
                System.Diagnostics.Debug.WriteLine($"[PinyinEngine] Backspace. New Buffer: {_inputBuffer}");
            }
        }

        public void Reset()
        {
            _inputBuffer.Clear();
            System.Diagnostics.Debug.WriteLine($"[PinyinEngine] Buffer reset.");
        }

        public List<string> GetCandidates()
        {
            string currentPinyin = _inputBuffer.ToString();

            if (IsChineseMode && currentPinyin.Length > 0)
            {
                if (_pinyinDictionary.TryGetValue(currentPinyin, out List<string> candidates))
                {
                    System.Diagnostics.Debug.WriteLine($"[PinyinEngine] Found {candidates.Count} candidates for '{currentPinyin}'.");
                    return candidates;
                }
                else
                {
                    System.Diagnostics.Debug.WriteLine($"[PinyinEngine] No exact match found for '{currentPinyin}'.");
                }
            }

            return new List<string>();
        }

        /// <summary>
        /// �ύ��ǰ��Ѻ�ѡ�ʣ��ո������ʱ���ã� (MainWindow �����˷���)��
        /// </summary>
        public string CommitBest()
        {
            var candidates = GetCandidates();
            string bufferContent = Buffer;

            if (candidates.Any())
            {
                string result = candidates.First();
                // ���޸����Ƴ� Reset()
                return result;
            }

            // ���û�к�ѡ�ʣ����ػ��������ݣ���ƴ��������
            // ���޸����Ƴ� Reset()
            return bufferContent;
        }

        /// <summary>
        /// �ύѡ�еĺ�ѡ�ʣ������ѡ��ʱ���ã� (MainWindow �����˷���)��
        /// </summary>
        public string PickCandidate(int index)
        {
            var candidates = GetCandidates();
            if (index >= 0 && index < candidates.Count)
            {
                string result = candidates[index];
                // ���޸����Ƴ� Reset()
                return result;
            }
            return null;
        }
    }
}